# Project Synopsis — AUTOSAR HLD Document Analysis Assistant

## 1. Project Title
**AUTOSAR HLD Document Analysis Assistant**

---

## 2. Institutional Information
- **Institution**: Pimpri Chinchwad College of Engineering (PCCOE), Pune
- **Department**: Department of Computer Engineering / Artificial Intelligence & Machine Learning
- **Academic Year**: 2025–2026 / 2026–2027
- **Candidate Name(s)**: [Student Full Name(s)]
- **PRN**: [Student PRN(s)]
- **Project Mentor / Guide**: [Faculty Guide Name]

---

## 3. Problem Statement
High-Level Design (HLD) specifications for automotive electronic control units (ECUs) following the AUTOSAR (AUTomotive Open System ARchitecture) standard are dense, highly interconnected documents often comprising hundreds of pages. Automotive software engineers and safety managers spend substantial manual effort navigating cross-references, verifying interface-to-port mappings, validating signal update rates, and tracing architectural revisions. Existing search tools rely on basic keyword matching that fails to interpret structured domain relationships, resulting in missed architectural inconsistencies, delayed design reviews, and expensive defect propagation into implementation.

---

## 4. Motivation & Objectives
1. **Reduce Review Latency**: Accelerate manual review of multi-page AUTOSAR HLD specifications by providing natural-language search and grounded answers.
2. **Convert Documents to Knowledge**: Parse unstructured PDF documentation into structured, searchable vector indices and formal architectural catalogs.
3. **Structured Entity Extraction**: Automatically catalogue Software Components (SWCs), Provided/Required Ports, Interfaces, Signals, and Functional Flows.
4. **Verifiable Citations**: Ensure every generated answer includes exact document, page number, and section references without fabrication.
5. **Revision Auditing**: Automate diffing between successive document baselines (e.g. Release 1.0 vs Release 2.0).
6. **Defect & Inconsistency Detection**: Flag conflicting timing constraints, undefined interface references, and undeclared components for engineering review.
7. **Empirical Evaluation**: Objectively measure retrieval recall, citation validity, and abstention performance against a documented evaluation benchmark.

---

## 5. Proposed Methodology & Architecture
The system employs an end-to-end, modular Retrieval-Augmented Generation (RAG) architecture:
1. **Document Ingestion**: PyMuPDF extracts text, headings, and tables; Tesseract OCR provides fallback for scanned pages.
2. **Context-Aware Chunking**: Text is segmented along structural paragraph and section boundaries, attaching metadata (`doc_id`, `filename`, `page_num`, `section`).
3. **Local Vector Storage**: Chunks are embedded using Sentence-Transformers (`all-MiniLM-L6-v2`) and indexed locally in ChromaDB.
4. **RAG Pipeline**: Top-k relevant passages are retrieved using cosine similarity. If the query lies outside the document domain, the system abstains. Otherwise, context is assembled and grounded responses are synthesized via the Google Gemini API with strict anti-hallucination prompt constraints.
5. **Rule-Based Consistency Engine**: Analyzes signal dictionaries and functional chains to identify discrepancies.
6. **User Interface**: Streamlit application providing 10 interactive navigation sections.

---

## 6. Technology Stack
- **Programming Language**: Python 3.13 / 3.11-compatible
- **User Interface**: Streamlit
- **PDF Extraction & OCR**: PyMuPDF (`pymupdf`), Pillow, Pytesseract
- **Vector Database**: ChromaDB (Local persistent)
- **Embedding Model**: Sentence-Transformers (`all-MiniLM-L6-v2`)
- **LLM Provider**: Google Gemini API via official `google-genai` SDK
- **Testing & Evaluation**: pytest, pandas, reportlab, matplotlib

---

## 7. Expected Outcomes & Evaluation
- High retrieval accuracy (>85% Recall@k on architectural lookups; benchmark achieved 100%).
- 100% citation verification rate matching actual source chunks.
- Accurate abstention on unsupported negative queries.
- Instant automated revision diffing and inconsistency reporting.
- Export of findings into CSV/JSON formats for automotive ALM integration.

---

## 8. Approvals & Signatures
- **Student Signature(s)**: *(Pending physical submission)*
- **Guide Approval**: *(Pending review)*
- **Date**: [DD/MM/YYYY]
